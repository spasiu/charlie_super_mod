#!/usr/bin/env bash
# Installs Stasi's mods into a Minecraft folder, plus the "realistic" graphics
# (Sodium + Iris + Complementary Unbound shaders, downloaded from Modrinth).
# Usage: ./install.sh [--no-shaders] [path-to-minecraft-folder]
# You still need Fabric Loader for Minecraft 26.3 installed (see README.md / INSTALL.txt).
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
SHADERS=1
if [ "${1:-}" = "--no-shaders" ]; then SHADERS=0; shift; fi
# the jars sit in dist/mods/ in the repo, or in mods/ next to this script in the release zip
if [ -d "$HERE/dist/mods" ]; then SRC="$HERE/dist/mods"; else SRC="$HERE/mods"; fi
if [ -n "${1:-}" ]; then
  MC="$1"
elif [ "$(uname)" = "Darwin" ]; then
  MC="$HOME/Library/Application Support/minecraft"
else
  MC="$HOME/.minecraft"
fi
ls "$SRC"/*.jar >/dev/null 2>&1 || { echo "No jars in $SRC — run 'python3 make-zip.py' first or download a release zip." >&2; exit 1; }
[ -d "$MC" ] || { echo "Minecraft folder not found at: $MC" >&2; echo "Run Minecraft once, or pass the folder: ./install.sh /path/to/minecraft" >&2; exit 1; }
mkdir -p "$MC/mods"
echo "Installing into $MC/mods"

put() {  # put <jar-or-zip> <dest-dir>: copy, removing older versions of the same thing (two versions = crash)
  local file="$1" dest="$2" name base
  name="$(basename "$file")"
  base="${name%%-[0-9]*}"                     # underworld-1.9.1.jar -> underworld
  base="${base%%_r[0-9]*}"                    # ComplementaryUnbound_r5.9.3.zip -> ComplementaryUnbound
  for old in "$dest/$base"-[0-9]* "$dest/$base"_r[0-9]*; do
    [ -e "$old" ] && [ "$(basename "$old")" != "$name" ] && { echo "  - removing old $(basename "$old")"; rm -f "$old"; }
  done
  cp -f "$file" "$dest/$name" && echo "  + $name"
}
for jar in "$SRC"/*.jar; do put "$jar" "$MC/mods"; done

if [ "$SHADERS" = 1 ]; then
  echo
  echo "Realistic graphics (Sodium, Iris, Complementary Unbound shaders)"
  TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
  fetch() {  # fetch <url> <file name> <sha512> <dest-dir>
    curl -fsSL "$1" -o "$TMP/$2" || { echo "  !! could not download $2 — skipped (check your internet connection)"; return 0; }
    local got; got="$( (shasum -a 512 "$TMP/$2" 2>/dev/null || sha512sum "$TMP/$2") | cut -d' ' -f1)"
    [ "$got" = "$3" ] || { echo "  !! $2 failed its checksum — skipped"; return 0; }
    mkdir -p "$4"; put "$TMP/$2" "$4"
  }
  fetch "https://cdn.modrinth.com/data/AANobbMI/versions/bAZQdGpg/sodium-fabric-0.9.2%2Bmc26.3.jar" "sodium-fabric-0.9.2+mc26.3.jar" \
    f3f260f204b8ce5e8777c2c73f537956755ec61f3817b0b78b5e5568e8aa40f14891f146475075109747665c7c88a45ca0ca9a8df3c68d79c58ecdaa8d8c4b93 "$MC/mods"
  fetch "https://cdn.modrinth.com/data/YL57xq9U/versions/bAdKrpw8/iris-fabric-1.11.6%2Bmc26.3.jar" "iris-fabric-1.11.6+mc26.3.jar" \
    cd0fdc5a275a851b3d72e3e699c957671f293f5c87951736ad83adcdabaa58f533e9791110a227c7817b312269c32c063121b183a39d8c11a22e55d2c76cdb25 "$MC/mods"
  fetch "https://cdn.modrinth.com/data/R6NEzAwj/versions/B1kyfoUZ/ComplementaryUnbound_r5.9.3.zip" "ComplementaryUnbound_r5.9.3.zip" \
    a085d1d8cda67cd17a2b414eeba48bbd809da069f269bab46246235ec8fe714a275013c70d0504527b0987d810deddddba4564332414ab3b3bd7435932ff808c "$MC/shaderpacks"
  mkdir -p "$MC/config"
  if [ -f "$MC/config/iris.properties" ] && grep -q '^shaderPack=.' "$MC/config/iris.properties"; then
    echo "  (keeping your existing shader choice in config/iris.properties)"
  else
    printf 'enableShaders=true\nshaderPack=ComplementaryUnbound_r5.9.3.zip\nmaxShadowRenderDistance=32\n' > "$MC/config/iris.properties"
    echo "  + shaders switched on (config/iris.properties)"
  fi
fi
echo
echo "Done. Start the 'fabric-loader-26.3' profile in the Minecraft Launcher."
