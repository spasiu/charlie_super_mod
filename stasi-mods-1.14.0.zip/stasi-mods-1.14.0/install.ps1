# Installs Stasi's mods into a Minecraft folder, plus the "realistic" graphics
# (Sodium + Iris + Complementary Unbound shaders, downloaded from Modrinth).
# Usage:  .\install.ps1 [-NoShaders] [path-to-minecraft-folder]      (or double-click install.bat)
# You still need Fabric Loader for Minecraft 26.3 installed (see README.md / INSTALL.txt).
param([string]$MinecraftDir = "$env:APPDATA\.minecraft", [switch]$NoShaders)
$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
# the jars sit in dist\mods\ in the repo, or in mods\ next to this script in the release zip
$Src = Join-Path $PSScriptRoot "dist\mods"
if (-not (Test-Path $Src)) { $Src = Join-Path $PSScriptRoot "mods" }
if (-not (Get-ChildItem -Path $Src -Filter *.jar -ErrorAction SilentlyContinue)) { Write-Error "No jars in $Src - run 'python make-zip.py' first or download a release zip."; exit 1 }
if (-not (Test-Path $MinecraftDir)) { Write-Error "Minecraft folder not found at $MinecraftDir. Run Minecraft once, or pass the folder: .\install.ps1 C:\path\to\minecraft"; exit 1 }
$Mods = Join-Path $MinecraftDir "mods"
New-Item -ItemType Directory -Force -Path $Mods | Out-Null
Write-Host "Installing into $Mods"

# Copy a file into a folder, removing older versions of the same thing first (two versions = crash).
function Put([string]$File, [string]$Dest) {
    $name = Split-Path $File -Leaf
    $base = ($name -replace '-[0-9].*$', '') -replace '_r[0-9].*$', ''
    Get-ChildItem -Path $Dest -File | Where-Object {
        ($_.Name -match "^$([regex]::Escape($base))(-[0-9]|_r[0-9])") -and $_.Name -ne $name
    } | ForEach-Object { Write-Host "  - removing old $($_.Name)"; Remove-Item $_.FullName -Force }
    Copy-Item $File (Join-Path $Dest $name) -Force
    Write-Host "  + $name"
}
Get-ChildItem -Path $Src -Filter *.jar | ForEach-Object { Put $_.FullName $Mods }

if (-not $NoShaders) {
    Write-Host ""
    Write-Host "Realistic graphics (Sodium, Iris, Complementary Unbound shaders)"
    $Tmp = Join-Path ([IO.Path]::GetTempPath()) ("stasi-mods-" + [Guid]::NewGuid())
    New-Item -ItemType Directory -Force -Path $Tmp | Out-Null
    $ShaderDir = Join-Path $MinecraftDir "shaderpacks"
    $extras = @(
        @{ Url = "https://cdn.modrinth.com/data/AANobbMI/versions/bAZQdGpg/sodium-fabric-0.9.2%2Bmc26.3.jar"; Name = "sodium-fabric-0.9.2+mc26.3.jar"; Dest = $Mods
           Sha = "f3f260f204b8ce5e8777c2c73f537956755ec61f3817b0b78b5e5568e8aa40f14891f146475075109747665c7c88a45ca0ca9a8df3c68d79c58ecdaa8d8c4b93" },
        @{ Url = "https://cdn.modrinth.com/data/YL57xq9U/versions/bAdKrpw8/iris-fabric-1.11.6%2Bmc26.3.jar"; Name = "iris-fabric-1.11.6+mc26.3.jar"; Dest = $Mods
           Sha = "cd0fdc5a275a851b3d72e3e699c957671f293f5c87951736ad83adcdabaa58f533e9791110a227c7817b312269c32c063121b183a39d8c11a22e55d2c76cdb25" },
        @{ Url = "https://cdn.modrinth.com/data/R6NEzAwj/versions/B1kyfoUZ/ComplementaryUnbound_r5.9.3.zip"; Name = "ComplementaryUnbound_r5.9.3.zip"; Dest = $ShaderDir
           Sha = "a085d1d8cda67cd17a2b414eeba48bbd809da069f269bab46246235ec8fe714a275013c70d0504527b0987d810deddddba4564332414ab3b3bd7435932ff808c" }
    )
    foreach ($e in $extras) {
        $out = Join-Path $Tmp $e.Name
        try { Invoke-WebRequest -Uri $e.Url -OutFile $out -UseBasicParsing }
        catch { Write-Host "  !! could not download $($e.Name) - skipped (check your internet connection)"; continue }
        if ((Get-FileHash $out -Algorithm SHA512).Hash.ToLower() -ne $e.Sha) { Write-Host "  !! $($e.Name) failed its checksum - skipped"; continue }
        New-Item -ItemType Directory -Force -Path $e.Dest | Out-Null
        Put $out $e.Dest
    }
    Remove-Item $Tmp -Recurse -Force -ErrorAction SilentlyContinue
    $Config = Join-Path $MinecraftDir "config"
    New-Item -ItemType Directory -Force -Path $Config | Out-Null
    $IrisProps = Join-Path $Config "iris.properties"
    if ((Test-Path $IrisProps) -and (Select-String -Path $IrisProps -Pattern '^shaderPack=.' -Quiet)) {
        Write-Host "  (keeping your existing shader choice in config\iris.properties)"
    } else {
        Set-Content -Path $IrisProps -Encoding ASCII -Value "enableShaders=true`r`nshaderPack=ComplementaryUnbound_r5.9.3.zip`r`nmaxShadowRenderDistance=32"
        Write-Host "  + shaders switched on (config\iris.properties)"
    }
}
Write-Host ""
Write-Host "Done. Start the 'fabric-loader-26.3' profile in the Minecraft Launcher."
