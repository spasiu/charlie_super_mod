@echo off
rem Double-click me to install Stasi's mods (and the realistic shaders) into Minecraft.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" %*
pause
